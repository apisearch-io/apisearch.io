<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{apisearch}prestashop>apisearch_2e5d8aa3dfa8ef34ca5131d20f9dad51'] = 'Configuració';
$_MODULE['<{apisearch}prestashop>apisearch_06aa87356105700329a9636114d765a2'] = 'Activar el cercador a la meva botiga';
$_MODULE['<{apisearch}prestashop>apisearch_ba518ec1f8376250f942befcd4491534'] = 'ID de Aplicació';
$_MODULE['<{apisearch}prestashop>apisearch_ec186d203e9a72d3bbef34250ed99cb9'] = 'ID de Índex';
$_MODULE['<{apisearch}prestashop>apisearch_a41071261328cc8380ef9c12763e6fee'] = 'Indexar productes sense imatge';
$_MODULE['<{apisearch}prestashop>apisearch_9ed94ae3bcdde1900ec69fd9d6e76b50'] = 'Indexar productes no disponibles';
$_MODULE['<{apisearch}prestashop>apisearch_26c44fd62f39aa0e883ca89f1a4eafab'] = 'Afegir número de ventes en els productes';
$_MODULE['<{apisearch}prestashop>apisearch_1a442debfe439990c007ba72d0b32beb'] = 'Crearem una representació de les ventes del producto assignat a un valor del 0 al 1000. En cap moment enviarem informació real sobre les teves ventes.';
$_MODULE['<{apisearch}prestashop>apisearch_494a99d5c7c4053e8fdb56f5130d512f'] = 'Afegir IDs de proveïdors';
$_MODULE['<{apisearch}prestashop>apisearch_4036dd19fbe26f37e014bb88d89b41d4'] = 'Afegir descripcions curtes';
$_MODULE['<{apisearch}prestashop>apisearch_499e16b57c50fe993a5bcb5e687a8fc5'] = 'En el cas que en les teves descripcions curtes hi hagi contexte important del producte, activa aquesta opció. Afegir la descripció pot, en molts casos, decrementar l\'eficiència de la cerca i la qualitat dels resultats';


$_MODULE['<{apisearch}prestashop>apisearch_a6105c0a611b41b08f1209506350279e'] = 'Si';
$_MODULE['<{apisearch}prestashop>apisearch_7fa3b767c460b54a2be4d49030b349c7'] = 'No';
$_MODULE['<{apisearch}prestashop>apisearch_43781db5c40ecc39fd718685594f0956'] = 'Guardar';
$_MODULE['<{apisearch}prestashop>apisearch_11500d04ea3917407ef54c840977b973'] = 'Panell d\'administració d\'Apisearch';


$_MODULE['<{apisearch}prestashop>apisearch_62e5cde27ad49944de104bbe346fd8e8'] = 'Integra Apisearch a la teva botiga per a una cerca ràpida i eficaç, millorant així l\'experiència dels teus usuaris i augmentant les teves vendes.';
