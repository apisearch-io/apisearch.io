<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{apisearch}prestashop>apisearch_2e5d8aa3dfa8ef34ca5131d20f9dad51'] = 'Configuració';
$_MODULE['<{apisearch}prestashop>apisearch_06aa87356105700329a9636114d765a2'] = 'Activar el cercador a la meva botiga';
$_MODULE['<{apisearch}prestashop>apisearch_ec186d203e9a72d3bbef34250ed99cb9'] = 'ID de l\'índex';
$_MODULE['<{apisearch}prestashop>apisearch_a41071261328cc8380ef9c12763e6fee'] = 'Indexar productes sense imatge';
$_MODULE['<{apisearch}prestashop>apisearch_9ed94ae3bcdde1900ec69fd9d6e76b50'] = 'Indexar productes no disponibles';
$_MODULE['<{apisearch}prestashop>apisearch_26c44fd62f39aa0e883ca89f1a4eafab'] = 'Afegir número de ventes en els productes';
$_MODULE['<{apisearch}prestashop>apisearch_1a442debfe439990c007ba72d0b32beb'] = 'Crearem una representació de les ventes del producto assignat a un valor del 0 al 1000. En cap moment enviarem informació real sobre les teves ventes.';
$_MODULE['<{apisearch}prestashop>apisearch_494a99d5c7c4053e8fdb56f5130d512f'] = 'Afegir IDs de proveïdors';
$_MODULE['<{apisearch}prestashop>apisearch_4036dd19fbe26f37e014bb88d89b41d4'] = 'Afegir descripcions curtes';
$_MODULE['<{apisearch}prestashop>apisearch_499e16b57c50fe993a5bcb5e687a8fc5'] = 'En el cas que en les teves descripcions curtes hi hagi contexte important del producte, activa aquesta opció. Afegir la descripció pot, en molts casos, decrementar l\'eficiència de la cerca i la qualitat dels resultats';
$_MODULE['<{apisearch}prestashop>apisearch_05933fee152b09de4cc7007780958f2d'] = 'Afegir descripcions llargues';
$_MODULE['<{apisearch}prestashop>apisearch_6f004d7ddcbfd3d973fa5ceacc6494ce'] = 'Pots indexar les descripcions llargues en el cas que ho necessitis. Aquest valor tindrà prioritat respecte la descripció curta en cas que estigui sel·leccionada. Aquesta opció fot afegir molt text irrellevant a la cerca i generarà long tail a totes les cerques, amb o sense resultats';
$_MODULE['<{apisearch}prestashop>apisearch_98ae660e070aac4118b4618ddb9134fd'] = 'Activar B2B';
$_MODULE['<{apisearch}prestashop>apisearch_49279bc316963e9aff1db1460fd7526c'] = 'Mostra uns preus o uns altres en funció de l\'usuari que el visualitza i del grup al que pertany. Per a testejar, pots forçar la visualització per a un grup d\'usuaris afegint el paràmetre apisearch_group_id i/o el paràmetre apisearch_customer_id a la URL';
$_MODULE['<{apisearch}prestashop>apisearch_cc386a578bf90387d4991c3a5b2d0fa7'] = 'Indexar imatges per color';
$_MODULE['<{apisearch}prestashop>apisearch_448c00326fbf94b280405f07a079dc13'] = 'Si actives un filtre de colors en el teu cercador, es mostrarà l\'imatge del color filtrat. En cas contrari, sempre es mostrarà l\'imatge principal';
$_MODULE['<{apisearch}prestashop>apisearch_4c2794db0c12899301ea956b99287a72'] = 'Mostrar preus sense IVA';
$_MODULE['<{apisearch}prestashop>apisearch_95177dc14299e2e57f993023ba664d6d'] = 'Excluir l\'IVA als preus del cercador. Aquest valor es pot sobreescriure a la URL del feed afegint valor al paràmetre vat';
$_MODULE['<{apisearch}prestashop>apisearch_60685f06115c0e958eecdaf859b21865'] = 'Agrupar variants per color';
$_MODULE['<{apisearch}prestashop>apisearch_d42f1aac66ee5795ab8e9c52aa1cf910'] = 'Cada grup de variants amb el mateix color seran agrupats en un producte. L\'imatge que s\'escollirà per a cada un dels grups serà l\'imatge de la primera variant del mateix. Asseguri\'s que totes les variants amb el mateix color tenen la mateixa imatge';
$_MODULE['<{apisearch}prestashop>apisearch_460c2634eaaab84607728765982c055a'] = 'Tipus d\'imatge';
$_MODULE['<{apisearch}prestashop>apisearch_14de2d5b683041953b07bc51ef2f09e5'] = 'Per defecte, la imatge del tipus home_default s\'utilitzarà. Canvia aquest valor si desitges carregar un altre tipus d\'imatge. Només seleccionables els tipus d\'imatges assignades a productes';
$_MODULE['<{apisearch}prestashop>apisearch_da3ad3b4322b19b609e4fa9d0a98a97b'] = 'Ordenar productes';
$_MODULE['<{apisearch}prestashop>apisearch_a84a585e060373cbe0329749c5653c77'] = 'Ordre per defecte dels productes al cercador. Sense aplicar cap ordre específic, els productes s’enviaran a Apisearch ordenats segons configuració. A més, en última instància, quan dos productes tinguin la mateixa puntuació, aquest ordre també s’aplicarà.';
$_MODULE['<{apisearch}prestashop>apisearch_639f40c2a6a9dbeddc9114253f1ac580'] = 'De més antic a més nou';
$_MODULE['<{apisearch}prestashop>apisearch_637c7cf48a31ea9cdc9496be9373da44'] = 'De més nou a més antic';
$_MODULE['<{apisearch}prestashop>apisearch_890a44bb38e82f7bfa0458465d1bb44f'] = 'Per estoc';
$_MODULE['<{apisearch}prestashop>apisearch_85c2dc7948fc1ae27a9254d86167589a'] = 'Per nombre total de vendes';
$_MODULE['<{apisearch}prestashop>apisearch_da5b0d4e44328191769f083a2fde3bdb'] = 'Primer els actualitzats recentment';
$_MODULE['<{apisearch}prestashop>apisearch_5f853e04d442c97ef1e10e03e9c377bc'] = 'Activar preus en temps real';
$_MODULE['<{apisearch}prestashop>apisearch_188c0026d43a98849b74ab9619037c05'] = 'Per a cada producte que es mostri al cercador, Apisearch calcularà els preus dinàmicament segons l’usuari. Aquest procés requereix utilitzar el teu Prestashop en temps real, per la qual cosa afectarà directament al rendiment de la cerca.';

$_MODULE['<{apisearch}prestashop>apisearch_a6105c0a611b41b08f1209506350279e'] = 'Si';
$_MODULE['<{apisearch}prestashop>apisearch_7fa3b767c460b54a2be4d49030b349c7'] = 'No';
$_MODULE['<{apisearch}prestashop>apisearch_43781db5c40ecc39fd718685594f0956'] = 'Guardar';
$_MODULE['<{apisearch}prestashop>apisearch_11500d04ea3917407ef54c840977b973'] = 'Panell d\'administració d\'Apisearch';


$_MODULE['<{apisearch}prestashop>apisearch_62e5cde27ad49944de104bbe346fd8e8'] = 'Integra Apisearch a la teva botiga per a una cerca ràpida i eficaç, millorant així l\'experiència dels teus usuaris i augmentant les teves vendes.';
