<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{apisearch}prestashop>apisearch_b82b69a0195251e4968dbac02f6336c1'] = 'Apisearch';
$_MODULE['<{apisearch}prestashop>apisearch_57aa7273acb0faea009438652f051091'] = 'Busca sobre tus productos y aporta a los clientes una experiencia única.';
$_MODULE['<{apisearch}prestashop>apisearch_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{apisearch}prestashop>apisearch_78d7dc9b19702caef319c11bdb7c4533'] = 'App Hash ID';
$_MODULE['<{apisearch}prestashop>apisearch_07781a6bbfb4727cd70616f14874891b'] = 'Index Hash ID';
$_MODULE['<{apisearch}prestashop>apisearch_74652ca98fdc8024026ab2fc53644a62'] = 'Management token Hash ID';
$_MODULE['<{apisearch}prestashop>apisearch_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{apisearch}prestashop>apisearch_9d55fc80bbb875322aa67fd22fc98469'] = 'Asociación de tiendas';
$_MODULE['<{apisearch}prestashop>apisearch_146ffe2fd9fa5bec3b63b52543793ec7'] = 'Mostrar más';
$_MODULE['<{apisearch}prestashop>apisearch_c74ea6dbff701bfa23819583c52ebd97'] = 'Mostrar menos';
$_MODULE['<{apisearch}prestashop>apisearch_25bd6551aff1d8efa79bad27e886276b'] = 'Resultados:';
$_MODULE['<{apisearch}prestashop>apisearch_ae3d767585160250a6529a1b984babb8'] = 'No se encuentran resultados para:';
$_MODULE['<{apisearch}prestashop>apisearch_0b275442d6556cff30b75f37f1918899'] = 'Limpiar filtros';
$_MODULE['<{apisearch}prestashop>apisearch_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir al carrito';
$_MODULE['<{apisearch}prestashop>apisearch_6fd4bc260c650009bca0596aac89ca1d'] = 'Disponibles';
$_MODULE['<{apisearch}prestashop>apisearch_2705193cb6e6cacfe17ea752f480bb3e'] = 'No disponibles';
$_MODULE['<{apisearch}prestashop>apisearch_2cbdc96c0ddca90a51137e8983d07da3'] = 'Con descuento';
$_MODULE['<{apisearch}prestashop>apisearch_070cc1af8aad72eccd71987d0886f483'] = 'Sin descuento';
$_MODULE['<{apisearch}prestashop>configure_cde5429dbfd8a853fb33c58da02cea9a'] = 'Sincronizar productos';
