<?php

interface ApisearchIntegrationRates
{
    /**
     * @return bool
     */
    public static function isValid();

    /**
     * @param ApisearchContext $context
     * @param array $ids
     * @return ApisearchRate[]
     */
    public static function loadRates($context, $ids);
}