<?php

class ApisearchRating
{
    /**
     * @var ApisearchIntegrationRates
     */
    private static $ratingService = null;

    public static function load()
    {
        $all = [
            ApisearchSteavisgarantisRates::class
        ];

        foreach ($all as $integration) {
            if ($integration::isValid()) {
                self::$ratingService = $integration;
            }
        }
    }

    /**
     * @param ApisearchContext $context
     * @param array $ids
     * @return array|ApisearchRate[]
     */
    public static function getRatings($context, array $ids)
    {
        if (!self::$ratingService) {
            return [];
        }

        return self::$ratingService::loadRates($context, $ids);
    }
}