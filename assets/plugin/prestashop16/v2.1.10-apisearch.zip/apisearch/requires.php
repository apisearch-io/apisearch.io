<?php

require "ApisearchContext.php";

require "Model/ApisearchBuilder.php";
require "Model/ApisearchDefaults.php";
require "Model/ApisearchExporter.php";
require "Model/ApisearchManufacturer.php";
require "Model/ApisearchProduct.php";


require "Rates/ApisearchIntegrationRates.php";
require "Rates/ApisearchRate.php";
require "Rates/ApisearchRating.php";
require "Rates/ApisearchSteavisgarantisRates.php";