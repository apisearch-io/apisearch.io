<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{apisearch}prestashop>apisearch_2e5d8aa3dfa8ef34ca5131d20f9dad51'] = 'Configuración';
$_MODULE['<{apisearch}prestashop>apisearch_06aa87356105700329a9636114d765a2'] = 'Activar el buscador en mi tienda';
$_MODULE['<{apisearch}prestashop>apisearch_ec186d203e9a72d3bbef34250ed99cb9'] = 'ID del Índice';
$_MODULE['<{apisearch}prestashop>apisearch_a41071261328cc8380ef9c12763e6fee'] = 'Indexar productos sin imágen';
$_MODULE['<{apisearch}prestashop>apisearch_9ed94ae3bcdde1900ec69fd9d6e76b50'] = 'Indexar productos no disponibles';
$_MODULE['<{apisearch}prestashop>apisearch_26c44fd62f39aa0e883ca89f1a4eafab'] = 'Añadir número de ventas en los productos';
$_MODULE['<{apisearch}prestashop>apisearch_1a442debfe439990c007ba72d0b32beb'] = 'Crearemos una representación de las ventas del producto asignada a un valor del 0 al 1000. En ningún momento enviaremos información real sobre tus ventas.';
$_MODULE['<{apisearch}prestashop>apisearch_494a99d5c7c4053e8fdb56f5130d512f'] = 'Añadir IDs de proveedores';
$_MODULE['<{apisearch}prestashop>apisearch_4036dd19fbe26f37e014bb88d89b41d4'] = 'Añadir descripciones cortas';
$_MODULE['<{apisearch}prestashop>apisearch_499e16b57c50fe993a5bcb5e687a8fc5'] = 'En el caso de que en tus descripciones cortas haya contexto importante del producto, activa esta opción. Añadir la descripción puede, en muchos casos, disminuir la eficiencia de la búsqueda y la calidad de los resultados.';
$_MODULE['<{apisearch}prestashop>apisearch_98ae660e070aac4118b4618ddb9134fd'] = 'Activar B2B';
$_MODULE['<{apisearch}prestashop>apisearch_49279bc316963e9aff1db1460fd7526c'] = 'Muestra unos precios u otros en el buscador dependiendo del usuario que lo visualiza y del grupo al que perteneze. Funciona solo con grupo de usuarios. Para testear, puedes forzar la visualización para un grupo de usuarios añadiendo el parámetro apisearch_group_id en la URL con el ID.';

$_MODULE['<{apisearch}prestashop>apisearch_a6105c0a611b41b08f1209506350279e'] = 'Si';
$_MODULE['<{apisearch}prestashop>apisearch_7fa3b767c460b54a2be4d49030b349c7'] = 'No';
$_MODULE['<{apisearch}prestashop>apisearch_43781db5c40ecc39fd718685594f0956'] = 'Guardar';
$_MODULE['<{apisearch}prestashop>apisearch_11500d04ea3917407ef54c840977b973'] = 'Panel de administración de Apisearch';


$_MODULE['<{apisearch}prestashop>apisearch_62e5cde27ad49944de104bbe346fd8e8'] = 'Integra Apisearch en tu tienda para una búsqueda rápida y efectiva, mejorando así la experiencia de tus usuarios y aumentando tus ventas.';