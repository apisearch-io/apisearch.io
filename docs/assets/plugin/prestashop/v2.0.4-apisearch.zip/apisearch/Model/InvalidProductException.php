<?php

namespace Apisearch\Model;

use Exception;

class InvalidProductException extends Exception
{

}
