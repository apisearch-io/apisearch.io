<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{apisearch}prestashop>apisearch_2e5d8aa3dfa8ef34ca5131d20f9dad51'] = 'Configuració';
$_MODULE['<{apisearch}prestashop>apisearch_06aa87356105700329a9636114d765a2'] = 'Activar el cercador a la meva botiga';
$_MODULE['<{apisearch}prestashop>apisearch_ec186d203e9a72d3bbef34250ed99cb9'] = 'ID de l\'índex';
$_MODULE['<{apisearch}prestashop>apisearch_a41071261328cc8380ef9c12763e6fee'] = 'Indexar productes sense imatge';
$_MODULE['<{apisearch}prestashop>apisearch_9ed94ae3bcdde1900ec69fd9d6e76b50'] = 'Indexar productes no disponibles';
$_MODULE['<{apisearch}prestashop>apisearch_26c44fd62f39aa0e883ca89f1a4eafab'] = 'Afegir número de ventes en els productes';
$_MODULE['<{apisearch}prestashop>apisearch_1a442debfe439990c007ba72d0b32beb'] = 'Crearem una representació de les ventes del producto assignat a un valor del 0 al 1000. En cap moment enviarem informació real sobre les teves ventes.';
$_MODULE['<{apisearch}prestashop>apisearch_494a99d5c7c4053e8fdb56f5130d512f'] = 'Afegir IDs de proveïdors';
$_MODULE['<{apisearch}prestashop>apisearch_4036dd19fbe26f37e014bb88d89b41d4'] = 'Afegir descripcions curtes';
$_MODULE['<{apisearch}prestashop>apisearch_499e16b57c50fe993a5bcb5e687a8fc5'] = 'En el cas que en les teves descripcions curtes hi hagi contexte important del producte, activa aquesta opció. Afegir la descripció pot, en molts casos, decrementar l\'eficiència de la cerca i la qualitat dels resultats';
$_MODULE['<{apisearch}prestashop>apisearch_05933fee152b09de4cc7007780958f2d'] = 'Afegir descripcions llargues';
$_MODULE['<{apisearch}prestashop>apisearch_6f004d7ddcbfd3d973fa5ceacc6494ce'] = 'Pots indexar les descripcions llargues en el cas que ho necessitis. Aquest valor tindrà prioritat respecte la descripció curta en cas que estigui sel·leccionada. Aquesta opció fot afegir molt text irrellevant a la cerca i generarà long tail a totes les cerques, amb o sense resultats';
$_MODULE['<{apisearch}prestashop>apisearch_98ae660e070aac4118b4618ddb9134fd'] = 'Activar B2B';
$_MODULE['<{apisearch}prestashop>apisearch_49279bc316963e9aff1db1460fd7526c'] = 'Mostra uns preus o uns altres en funció de l\'usuari que el visualitza i del grup al que pertany. Per a testejar, pots forçar la visualització per a un grup d\'usuaris afegint el paràmetre apisearch_group_id i/o el paràmetre apisearch_customer_id a la URL';
$_MODULE['<{apisearch}prestashop>apisearch_cc386a578bf90387d4991c3a5b2d0fa7'] = 'Indexar imatges per color';
$_MODULE['<{apisearch}prestashop>apisearch_448c00326fbf94b280405f07a079dc13'] = 'Si actives un filtre de colors en el teu cercador, es mostrarà l\'imatge del color filtrat. En cas contrari, sempre es mostrarà l\'imatge principal';
$_MODULE['<{apisearch}prestashop>apisearch_4c2794db0c12899301ea956b99287a72'] = 'Mostrar preus sense IVA';
$_MODULE['<{apisearch}prestashop>apisearch_95177dc14299e2e57f993023ba664d6d'] = 'Excluir l\'IVA als preus del cercador. Aquest valor es pot sobreescriure a la URL del feed afegint valor al paràmetre vat';

$_MODULE['<{apisearch}prestashop>apisearch_a6105c0a611b41b08f1209506350279e'] = 'Si';
$_MODULE['<{apisearch}prestashop>apisearch_7fa3b767c460b54a2be4d49030b349c7'] = 'No';
$_MODULE['<{apisearch}prestashop>apisearch_43781db5c40ecc39fd718685594f0956'] = 'Guardar';
$_MODULE['<{apisearch}prestashop>apisearch_11500d04ea3917407ef54c840977b973'] = 'Panell d\'administració d\'Apisearch';


$_MODULE['<{apisearch}prestashop>apisearch_62e5cde27ad49944de104bbe346fd8e8'] = 'Integra Apisearch a la teva botiga per a una cerca ràpida i eficaç, millorant així l\'experiència dels teus usuaris i augmentant les teves vendes.';
