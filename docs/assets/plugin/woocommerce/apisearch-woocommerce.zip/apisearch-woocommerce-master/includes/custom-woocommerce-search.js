jQuery(document).ready(function($) {
    console.log('inside the apisearch javascript');
    // any other custom js here
});
